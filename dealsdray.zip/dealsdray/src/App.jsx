import React from 'react'
import Login from './Components/Login'
import Welcome from './Components/Welcome'
import CreateForm from './Components/CreateForm'

const App = () => {
  return (
    <>
      <Login />
      <Welcome />
      <CreateForm />
    </>

  )
}

export default App